namespace minhaConta{
    struct reg_extrato{
       float val;
       char tip;
    };
    
    class conta{
       private: float saldo;
       private: float limite;
       private: struct reg_extrato ext[1000];
       private: int i_ext;
       
       
       public: void abrir(float l){
          this-> limite = l;
          this->saldo = 0;
          this->i_ext = 0;
          this->addHis('A',this->limite);
       }
       
       private: void addHis(char c, float v){
          this->ext[this->i_ext].val = v;
          this->ext[this->i_ext].tip  = c;
          this->i_ext++;
       }
       
       public: void depositar(float v){
          this->saldo += v;
          this->addHis('C',v);
       }
       
       public: int sacar(float v){
          if(this->saldo + this->limite >= v){
             this->saldo -= v;
             this->addHis('D',v);
             return(1);
          }
          else{
             return(0);//sem saldo
          }
       }
       
       public: float getSaldo(){
          return(this->saldo);
       }
       
       public: void verExtrato(){
          int i;
          for(i=0;i<this->i_ext;i++){
             switch(this->ext[i].tip){
                case 'A': printf("\nAbertura de Conta no valor de %.2f",this->ext[i].val);
                break;
                case 'C': printf("\nDeposito no valor de %.2f",this->ext[i].val);
                break;
                case 'D': printf("\nSaque no valor de %.2f",this->ext[i].val);
                break;
             }
          }
       }
    
    };
}

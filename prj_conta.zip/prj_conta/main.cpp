
#include <stdio.h>
#include "conta.h"
#include <stdlib.h>
int main(){
   class minhaConta::conta ct_001;
   //M�todo para abrir a conta (define o limite da conta)
   ct_001.abrir(100);
   //M�todo para depositar na conta
   ct_001.depositar(1500.34);
   //retorna o saldo atual
   printf("Saldo R$ %.2f\n",ct_001.getSaldo());
   //m�todo para sacar (verificar se possui saldo + limite para saque)
   ct_001.sacar(1550.34);
   //retorna o saldo atual
   printf("Saldo R$ %.2f\n",ct_001.getSaldo());
   ct_001.verExtrato();
   printf("\n");
   system("pause");
}
